import { useState } from "react";
import "./App.css";
import { Configuration , OpenAIApi } from 'openai'
import OptionsSelection from "./components/OptionsSelection";
import Selections from "./components/Selections";

function App() {
  const configuration = new Configuration({
    apiKey:'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',
  });
  const openai = new OpenAIApi(configuration);
  const [data , setData] = useState("");
  const [theme, setTheme] = useState(false);
  const [option, setOption] = useState(0);
  const [input , setInput] = useState("")
  const [id , setId] = useState(null);
  const selectedOption = (option , id) => {
    setOption(option);
    setId(id);
  };
  const proceedRequest = async(i) => {
    let obj = {...option , prompt: i};
    const response = await openai.createCompletion(obj);
    setData(response.data.choices[0].text);
  }
  return (
    <div
      className={`App ${theme ? "bg-dark text-white" : "bg-light text-dark"}`}
    >
      <div className='d-flex justify-content-evenly align-items-center pt-2'>
        {
          Object.values(option).length === 0 ? 
          null :
          <a className='text-primary cursor-pointer' href="/">Back</a>
        }
        <h1>Intellitron : <span style={{fontSize:"27px"}}>React AI App</span></h1>
        <div className="form-check form-switch">
          <input className="form-check-input" type="checkbox" id="theme" onClick={() => setTheme(!theme)} />
          <label className="form-check-label" for="theme">{theme ? 'Dark Mode' : 'Light Mode'}</label>
        </div>
      </div>
      {Object.values(option).length === 0 ? (
        <OptionsSelection
          setTheme={setTheme}
          theme={theme}
          selectedOption={selectedOption}
        />
      ) : (
        <Selections id={id} setInput={setInput} theme={theme} proceedRequest={proceedRequest} input={input} data={data}  />
      )}
    </div>
  );
}

export default App;

export const optionData = [
  {
    id: 1,
    name: "Q&A : the sarcastic chat bot",
    option: {
      model: "text-davinci-003",
      temperature: 0.5,
      max_tokens: 60,
      top_p: 0.3,
      frequency_penalty: 0.5,
      presence_penalty: 0.0,
    },
    note : `use this before your question for funny experience : Marv is a chatbot that reluctantly answers questions with sarcastic responses:`,
    description: "Marv is a chatbot that reluctantly answers questions with sarcastic responses:",
  },
  {
    id: 2,
    name: "Grammar correction",
    option: {
      model: "text-davinci-003",
      temperature: 0,
      max_tokens: 200,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
    },
    note : "Use this before : Correct this to standard English:",
    description: "Corrects sentences into standard English.",
  },
  {
    id: 3,
    name: "Summarize for a 2nd grader",
    option: {
      model: "text-davinci-003",
      temperature: 0.7,
      max_tokens: 64,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
    },
    note : "Use this before : Summarize this for a second-grade student:",
    description: "Translates difficult text into simpler concepts.",
  },

  {
    id: 4,
    name: "Translate programming languages",
    option: {
      model: "code-davinci-002",
      temperature: 0,
      max_tokens: 54,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
      stop: ["###"],
    },
    note : `Use this before : ##### Translate this function  from language_in_which_your_code_is_written (eg. python) into language_in_which_you_want_your_code (eg. java)
    ### language_in_which_your_code_is_written (eg. python) 
    your code .....
    ### language_in_which_you_want_your_code (eg. java) `,
    description:"To translate from one programming language to another we can use the comments to specify the source and target languages.",
  },

  {
    id: 5,
    name: "JavaScript helper chatbot",
    option: {
      model: "code-davinci-002",
      temperature: 0,
      max_tokens: 60,
      top_p: 1.0,
      frequency_penalty: 0.5,
      presence_penalty: 0.0,
      stop: ["You:"],
    },
    note : "",
    description:"This is a message-style chatbot that can answer questions about using JavaScript. It uses a few examples to get the conversation started.",
  },

  {
    id: 6,
    name: "Notes to summary",
    option: {
      model: "text-davinci-003",
      temperature: 0,
      max_tokens: 64,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
    },
    note : "Use this before : Convert my short hand into a first-hand account of the meeting:",
    description: "Turn meeting notes into a summary.",
  },
  {
    id: 7,
    name: "Create study notes",
    option: {
      model: "text-davinci-003",
      temperature: 0.3,
      max_tokens: 150,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
    },
    note : "",
    description: "Provide a topic and get study notes.",
  },
  {
    id: 8,
    name: "Ad from product description",
    option: {
      model: "text-davinci-003",
      temperature: 0.5,
      max_tokens: 100,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
    },
    note : `Use this before type of message send : Write a creative ad for the following product to run on Facebook aimed at parents:

    Product: Learning Room is a virtual environment to help students from kindergarten to high school excel in school.`,
    description:"Turn a product description into ad copy.",
  },
];

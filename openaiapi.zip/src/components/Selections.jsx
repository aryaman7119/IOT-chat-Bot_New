import React from "react";
import { optionData } from "../AIOptions/index";

const Selections = ({ theme, id, setInput, input, proceedRequest, data }) => {
  return (
    <div className="p-3 d-flex flex-column justify-content-center">
      <h5>{optionData[id - 1].name}</h5>
      <div className="form-outline d-flex justify-content-center">
        <textarea
          className="form-control w-75"
          placeholder={`${id !== null ? optionData[id - 1].description : null}`}
          id="textAreaExample2"
          rows="6"
          onChange={(e) => setInput(e.target.value)}
        ></textarea>
      </div>
      <div className="pt-4">
        {optionData[id - 1].note === "" ? null : (
          <p className="text-danger">
            <strong>******Note : </strong>
            <span> {optionData[id - 1].note}</span>
            <strong>******</strong>
          </p>
        )}
      </div>
      <div>
        <button
          className="mt-3 btn btn-primary px-4"
          onClick={() => proceedRequest(input)}
        >
          Proceed Request
        </button>
      </div>
      <div className={`pt-5  ${theme ? "text-white" : "text-black"}`}>
        <h3>Here's the response from {optionData[id - 1].name}</h3>
        <div className="d-flex justify-content-center">
        {
          data &&
          <p className={`text-wrap border p-3 respond_data  ${theme ? "bg-black" : "bg-white"}`}>
            {data}
          </p> 
        }
        </div>
      </div>
    </div>
  );
};

export default Selections;

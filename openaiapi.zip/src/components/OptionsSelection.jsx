import React from 'react'
import { optionData  } from '../AIOptions/index';
import  '../App.css'

const OptionsSelection = ({ theme , selectedOption}) => {
  return (
    <div className='container-fluid'>
      <div className='row gap-3 justify-content-center py-5'>
          {
            optionData.map((val) => {
              return (
                <div className={`col-11 col-md-5 col-lg-3 border rounded text-center ${ theme ? 'option_to_select_dark' : 'option_to_select_light'}`} key={val.id} onClick={() => selectedOption(val.option , val.id)}>
                  <h4 className='m-2 pt-3 px-1 fs-4'>{val.name}</h4>
                  <p className='px-1 pb-3 text-secondary fw-normal' style={{fontSize : '15px'}}>{val.description}</p>
                </div>
              )
            })
          }
      </div>
    </div>
  )
}

export default OptionsSelection